package cn.edu.xjtlu.cst105.week5.CW2;

import java.util.Scanner;

/**
 * CW2.1 Question 1
 */
public class Question1 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int x = scanner.nextInt();

        System.out.println("y = "+(5*x*x*x+2*x-88));
    }
}
