package cn.edu.xjtlu.cst105.week5.CW2;

import java.util.Scanner;

/**
 * CW2.1 Question 2
 */
public class Question2 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();

        System.out.println(a == b && b == c ? "equal" : "not equal");

    }
}
