package cn.edu.xjtlu.cst105.week5.CW2;

/**
 * CW2.1 Question 5
 */
public class Question5 {

    public static int[] shiftEvenNumber(int[] nums) {

        int[] newNums = new int[nums.length];

        for (int i = 0; i < nums.length; i++)
            newNums[i] = -1;

        for (int i = 0, j = 0; i < nums.length; i++)
            if (nums[i] % 2 != 0) newNums[j++] = nums[i];

        return newNums;
    }


    public static void main(String[] args) {
        test(new int[]{1, 2, 3, 4, 5,8,11,7,11,8,99});
        test(new int[]{10, 111, 33, 555});
    }


    static void printInts(int[] arr) {
        System.out.print("[");
        for (int i = 0; i < arr.length-1; i++)
            System.out.print(arr[i]+", ");
        System.out.println(arr[arr.length-1]+"]");
    }

    static void test(int[] nums) {
        printInts(shiftEvenNumber(nums));
    }

}
