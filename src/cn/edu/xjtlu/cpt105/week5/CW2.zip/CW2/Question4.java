package cn.edu.xjtlu.cst105.week5.CW2;

/**
 * CW2.1 Question 4
 */
public class Question4 {

    public static int countSeven(long num) {
        int count = 0;
        while (num > 10){
            if (num % 10 == 7) count++;
            num /= 10;
        }
        if (num == 7) count++;
        return count;
    }

    public static void main(String[] args) {
        testCountSeven(7);
        testCountSeven(722777227);
        testCountSeven(7777773);
    }

    static void testCountSeven(long num){
        System.out.println(countSeven(num));
    }

}
